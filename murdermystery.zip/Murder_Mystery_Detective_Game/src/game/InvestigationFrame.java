package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.TitledBorder;

public class InvestigationFrame extends JFrame {
    private GameManager gameManager;
    private JTextArea dialogueArea;
    private DefaultListModel<String> inventoryModel;
    private JList<String> inventoryList;
    private JComboBox<String> accuseComboBox;
    
    // Animation Attributes (Color shift logic variables)
    private int animationOffset = 0;
    private boolean directionUp = true;
    private Timer sceneTimer;

    public InvestigationFrame(GameManager gameManager) {
        this.gameManager = gameManager;

        setTitle("Crime Scene Investigation Room");
        setSize(750, 520); // Height ko components ke liye thoda barha diya hai
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Customized Animated Background Panel Pattern
        JPanel customAnimatedPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                
                // Mathematical equation to slowly morph colors smoothly
                Color upperColor = new Color(30 + animationOffset / 4, 42 + animationOffset / 3, 60 + animationOffset / 2);
                Color lowerColor = new Color(44 - animationOffset / 6, 62 - animationOffset / 5, 80);
                
                // Drawing dynamic software gradient layout
                GradientPaint runtimeGradient = new GradientPaint(0, 0, upperColor, getWidth(), getHeight(), lowerColor);
                g2d.setPaint(runtimeGradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        customAnimatedPanel.setLayout(new BorderLayout(10, 10));
        setContentPane(customAnimatedPanel); // Replaced default panel with animation layer

        // Setting up the Event Thread Animation loop Timer
        sceneTimer = new Timer(30, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (directionUp) {
                    animationOffset += 2;
                    if (animationOffset >= 110) directionUp = false;
                } else {
                    animationOffset -= 2;
                    if (animationOffset <= 0) directionUp = true;
                }
                repaint(); // Safely repaints the gradient background
            }
        });
        sceneTimer.start(); // Dynamic execution starts immediately

        //  Left Panel Setup (Suspect Buttons)
        JPanel leftPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        leftPanel.setOpaque(false); // Transparent to see animation
        
        // Custom TitledBorder with White Text
        TitledBorder leftBorder = BorderFactory.createTitledBorder("Interrogate Suspects");
        leftBorder.setTitleColor(Color.WHITE);
        leftPanel.setBorder(leftBorder);

        for (Suspect s : gameManager.getSuspects()) {
            JButton suspectBtn = new JButton(s.getName() + " (" + s.getRole() + ")");
            suspectBtn.setFont(new Font("Arial", Font.BOLD, 13)); // Made Bold for better design
            suspectBtn.setBackground(new Color(52, 73, 94));
            suspectBtn.setForeground(Color.WHITE);
            
            suspectBtn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String statement = s.interrogate();
                    dialogueArea.setText(s.getName() + ": \"" + statement + "\"");
                    
                    Clue c = s.giveClue();
                    boolean alreadyHasClue = false;
                    for (Clue heldClue : gameManager.getDetective().getInventory()) {
                        if (heldClue.getName().equals(c.getName())) {
                            alreadyHasClue = true;
                            break;
                        }
                    }
                    if (!alreadyHasClue) {
                        gameManager.getDetective().addClue(c);
                        inventoryModel.addElement(c.getName() + " -> " + c.getDescription());
                    }
                }
            });
            leftPanel.add(suspectBtn);
        }
        add(leftPanel, BorderLayout.WEST);

        // Center Panel Setup (Suspect Statements Output)
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        
        TitledBorder centerBorder = BorderFactory.createTitledBorder("Suspect Statements");
        centerBorder.setTitleColor(Color.WHITE);
        centerPanel.setBorder(centerBorder);
        
        dialogueArea = new JTextArea();
        dialogueArea.setFont(new Font("Serif", Font.PLAIN, 16));
        dialogueArea.setLineWrap(true);
        dialogueArea.setWrapStyleWord(true);
        dialogueArea.setEditable(false);
        
        // Semi-transparent light background so text is perfectly readable
        dialogueArea.setBackground(new Color(255, 255, 255, 220));
        dialogueArea.setForeground(Color.BLACK);
        centerPanel.add(new JScrollPane(dialogueArea), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        //  Right Panel Setup (Evidence Notebook)
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setPreferredSize(new Dimension(280, 100));
        rightPanel.setOpaque(false);
        
        TitledBorder rightBorder = BorderFactory.createTitledBorder("Evidence & Clue Notebook");
        rightBorder.setTitleColor(Color.WHITE);
        rightPanel.setBorder(rightBorder);
        
        inventoryModel = new DefaultListModel<>();
        inventoryList = new JList<>(inventoryModel);
        inventoryList.setBackground(new Color(255, 255, 255, 220)); // Semi-transparent list view
        inventoryList.setFont(new Font("Arial", Font.PLAIN, 12));
        rightPanel.add(new JScrollPane(inventoryList), BorderLayout.CENTER);
        add(rightPanel, BorderLayout.EAST);

        // Bottom Selection Bar Setup
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        bottomPanel.setBackground(new Color(30, 40, 55, 200)); // Dark semi-transparent color bar
        
        JLabel accuseLabel = new JLabel("Who is the Killer?");
        accuseLabel.setFont(new Font("Arial", Font.BOLD, 14));
        accuseLabel.setForeground(Color.WHITE); // Changed to White for visibility
        bottomPanel.add(accuseLabel);

        accuseComboBox = new JComboBox<>();
        for (Suspect s : gameManager.getSuspects()) {
            accuseComboBox.addItem(s.getName());
        }
        bottomPanel.add(accuseComboBox);

        JButton accuseBtn = new JButton("Arrest Suspect!");
        accuseBtn.setBackground(new Color(192, 41, 43)); // Changed to uniform Red Theme color
        accuseBtn.setForeground(Color.WHITE);
        accuseBtn.setFont(new Font("Arial", Font.BOLD, 14));
        
        accuseBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sceneTimer.stop(); // CRITICAL: Stop the clock before changing frame to avoid leaks
                
                String selectedSuspect = (String) accuseComboBox.getSelectedItem();
                boolean isRight = gameManager.checkAccusation(selectedSuspect);
                new ResultFrame(isRight, gameManager.getKiller()).setVisible(true);
                dispose();
            }
        });
        
        bottomPanel.add(accuseBtn);
        add(bottomPanel, BorderLayout.SOUTH);
    }
}